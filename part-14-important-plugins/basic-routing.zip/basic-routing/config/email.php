<?php
$config_email = array(
    'host'=>'smtp.gmail.com',
    'username'=>'tiennguyenvan2102001@gmail.com',
    'fullname'=>'Nguyen Van Tien',
    'password'=>'sulc nain ezds efmc',
    'smtp_secure'=>'tls',
    'port'=>'465',
);
?>